#ifndef Libreria0.h //Siempre el nombre de mi libreria a crear
#define Libreria0.h //Siempre el nombre de mi libreria a crear

#include "Arduino.h"  //este va si o si siempre

void mostrar_mensaje (String msj);





#endif
