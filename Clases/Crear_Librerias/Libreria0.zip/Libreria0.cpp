#include "Arduino.h"
#include "Libreria0.h"


void mostrar_mensaje (String msj){
  Serial.println(msj);
}

